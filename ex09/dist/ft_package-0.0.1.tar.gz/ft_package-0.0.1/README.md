
# ft_package

A simple Python package that provides a function to count
how many times an item appears in a list.

## Installation

```bash
pip install ./dist/ft_package-0.0.1.tar.gz
```

You can also install the wheel distribution:

```bash
pip install ./dist/ft_package-0.0.1-py3-none-any.whl
```

## Usage

```python
from ft_package import count_in_list

print(count_in_list(["toto", "tata", "toto"], "toto"))
print(count_in_list(["toto", "tata", "toto"], "tutu"))
```

Output:

```text
2
0
```
